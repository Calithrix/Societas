# Societas Term Index

*Placeholder for content.*